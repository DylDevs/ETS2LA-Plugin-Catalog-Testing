from .ultrafastLaneDetector import *
from .ultrafastLaneDetector import ultrafastLaneDetector, ultrafastLaneDetectorV2
